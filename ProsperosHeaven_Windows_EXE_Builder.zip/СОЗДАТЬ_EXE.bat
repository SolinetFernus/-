@echo off
chcp 65001 >nul
title PROSPEROS HEAVEN - EXE Builder

echo ==========================================
echo       PROSPEROS HEAVEN - EXE BUILDER
echo ==========================================
echo.

where py >nul 2>nul
if errorlevel 1 (
    echo Python не найден.
    echo Установите Python с https://www.python.org/downloads/
    echo Во время установки отметьте Add Python to PATH.
    pause
    exit /b 1
)

echo [1/3] Устанавливаем необходимые пакеты...
py -m pip install --upgrade pip
if errorlevel 1 goto error
py -m pip install flask pyinstaller
if errorlevel 1 goto error

echo.
echo [2/3] Собираем EXE...
py -m PyInstaller --noconfirm --clean --onefile --name ProsperosHeaven prosperos_heaven.py
if errorlevel 1 goto error

echo.
echo [3/3] Готово!
echo EXE находится здесь:
echo %CD%\dist\ProsperosHeaven.exe
echo.
echo Скопируйте EXE из папки dist в любое удобное место.
pause
exit /b 0

:error
echo.
echo Произошла ошибка сборки. Проверьте сообщения выше.
pause
exit /b 1
